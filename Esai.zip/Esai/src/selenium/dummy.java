package selenium;

public class dummy {
	public static void main(String[] args) {
		int s = 4;
		int area = s*s;
	    System.out.println("Area of square:" + area);
	}
	
	}


