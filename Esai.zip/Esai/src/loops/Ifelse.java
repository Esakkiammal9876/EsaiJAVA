package loops;

public class Ifelse {
	 public static void main(String[] args) {
		 
		 int a = 50;
		 int b= 400;

		 if(a>b) {
			 System.out.println("a is bigger");
		 }
		 else {
			 System.out.println("b is bigger");
			 
		 }
			 
	 }

}
