package loops;

public class Dowhile {
	
	public static void main(String[] args) {
		
		 int i = 3;
		 do {
			 System.out.println(i);
			 i=i+3;
		 }
		 while(i<=30);
	 }

}
