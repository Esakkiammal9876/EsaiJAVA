package loops;

public class Elseif {
	
	public static void main(String[] args) {
		 
		 int a = 40;
		 int b= 50;
		 int c = 100;
		
		 if(a>b && a>c) {
			 System.out.println("a is bigger");
		 }
		 else if (b>a && b>c) {
			 System.out.println("b is bigger");
			 
}
		
		 
		 else {
			 System.out.println("c is bigger");
		 }
	}
}