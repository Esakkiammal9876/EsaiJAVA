package encapsulation;

public class e1 {
	
	//String password = "abc333333";
	//int ab = 10;
	
	private String password;
	
	public void get() {
		System.out.println(password);
	}
	public void set(String p) {
		password=p;
	}

}
