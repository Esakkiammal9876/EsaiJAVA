package encapsulation;

public class e2 {
	public static void main(String[] args) {
		e1 ob = new e1();//parent class-create a obj 
		ob.set("abc123");
		ob.get();
	}

}

