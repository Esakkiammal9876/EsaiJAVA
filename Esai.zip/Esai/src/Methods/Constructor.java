package Methods;

public class Constructor {
	public static void main(String[] args) {
		Constructor obj = new Constructor();
	
	}
	public Constructor(){
		int a = 4;
		System.out.println("Area of square is " +a*a);
	}

}
