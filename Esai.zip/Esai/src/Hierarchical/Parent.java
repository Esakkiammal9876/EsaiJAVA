package Hierarchical;

public class Parent {
	
	
	public static void ps1() {
		System.out.println("Parent class static method ");
	}
	
	public void pn1() {
		System.out.println("Parent class non static method ");
	}
}