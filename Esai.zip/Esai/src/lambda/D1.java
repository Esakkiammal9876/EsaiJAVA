package lambda;

public interface D1 {
	
	public void pt();

}
