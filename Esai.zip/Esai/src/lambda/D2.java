package lambda;

public interface D2 {
	
	public void square(int side);

}
