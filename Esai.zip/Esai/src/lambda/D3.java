package lambda;

public interface D3 {
	
	public int add(int m,int n);

}
