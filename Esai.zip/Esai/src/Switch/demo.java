package Switch;

public class demo {
	public static void main(String[] args) {
		int age = 2;
		switch(age) {
		
		case 1 :
			System.out.println("new born baby");
			break;
			
		case 2 :
			System.out.println("lkg");
			break;
			default:
				System.out.println("not match");
				break;
		}
	}
	
}
