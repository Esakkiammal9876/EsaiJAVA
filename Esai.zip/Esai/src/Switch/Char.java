package Switch;

public class Char {
	public static void main(String[] args)
	{ 
		char initial = 'M';
		switch(initial) {
		
		case 'N':
			System.out.println('N');
			break;
		case 'V':
			System.out.println('V');
			break;
		case 'E':
			System.out.println('E');
			break;
			default:
				System.out.println("Invalid");
				break;
		}
	}
	
}

