package sprkeywrd;

public class parent {
	
	int age = 30;

}
