package polymorp;

public class parentor {
	
	public void area() {	
	int s=4;
	System.out.println("Area of sq is "+ s*s);
	
}
	
}