package fnl;

public class f1 {
	
	final static int age = 20;
	
	public static void main(String[] args) {
		//System.out.println(age);
		f1 f = new f1();
		f.display();
	}
	
	public void display() {
	System.out.println(age);
	}

}
