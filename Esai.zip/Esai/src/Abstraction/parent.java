package Abstraction;

 public abstract class parent {
	
	public void nm() {
		System.out.println("normal method ");
	}
	
	abstract public void ab();
	abstract public void cd();

}
