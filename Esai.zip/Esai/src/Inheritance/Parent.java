package Inheritance;

public class Parent {
	
	public static void ps() {
		System.out.println("Parent class static method ");
	}
	
	public void pn() {
		System.out.println("Parent class non static method ");
	}
}