package operators;

public class Op {
	
public static void main(String[] args) {
	
	int a = 10;
	
	
	a+=5;//a=a+5=15
	System.out.println(a);
	
	a-=6;//15-=6=15-6=9
	System.out.println(a);//a = 9

	a*=2;
	System.out.println(a); //a=18
	
	a/=2;
	System.out.println(a);
	
}

}
