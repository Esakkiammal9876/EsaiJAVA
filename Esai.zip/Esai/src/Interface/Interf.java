package Interface;

public interface Interf {
	
	default public  void nm() {
		System.out.println("non static method");
	}
	public void ab();

}
